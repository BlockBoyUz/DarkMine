from flask import Flask, render_template_string, request, jsonify, session, redirect, send_from_directory
from mcstatus import JavaServer
import json, os
from datetime import datetime
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'mrfayz_kot_nx'
app.config['UPLOAD_FOLDER'] = 'receipts'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
os.makedirs('receipts', exist_ok=True)

ADMIN_USER, ADMIN_PASS = "mrfayz", "mrfayz_kot"
CARD_NUMBER, CARD_HOLDER = "9860 0801 3691 2468", "Ibodova.M"

RANKS = {
    "VIP": {
        "price_1oy": 7000, "price_butun": 18000, "color": "#00FF00",
        "features": ["/vb", "/ec", "/kit claim vip", "7 ta mahsulotni auksionga sotish", "Region blok limiti: 3 ta", "Maksimal uylar soni: 2 ta"],
        "cmd": ["lp user {player} parent set vip", "lp user {player} permission set essentials.back"]
    },
    "CHAMPION": {
        "price_1oy": 10000, "price_butun": 25000, "color": "#FF00FF",
        "features": ["/ec", "/setwarp", "/kit claim champion", "/anvil", "10 ta mahsulotni auksionga sotish", "Region blok limiti: 5 ta", "Maksimal uylar soni: 3 ta"],
        "cmd": ["lp user {player} parent set champion"]
    },
    "IMPERATOR": {
        "price_1oy": 15000, "price_butun": 50000, "color": "#00FFFF",
        "features": ["/time set", "/ec", "/weather", "/kit claim imperator", "14 ta mahsulotni auksionga sotish", "Region blok limiti: 7 ta", "Maksimal uylar soni: 5 ta"],
        "cmd": ["lp user {player} parent set imperator"]
    },
    "DRAGON": {
        "price_1oy": 30000, "price_butun": 75000, "color": "#0099FF",
        "features": ["/jump", "/clear", "/ec", "/afk", "/kit claim dragon", "20 ta mahsulotni auksionga sotish", "Region blok limiti: 9 ta", "Maksimal uylar soni: 8 ta"],
        "cmd": ["lp user {player} parent set dragon"]
    },
    "GALACTIC": {
        "price_1oy": 40000, "price_butun": 100000, "color": "#FF0000",
        "features": ["/feed", "/heal", "/ec", "/kit claim", "30 ta mahsulotni auksionga sotish", "Region blok limiti: 11 ta", "Maksimal uylar soni: 12 ta"],
        "cmd": ["lp user {player} parent set galactic"]
    },
    "MAGICIAN": {
        "price_1oy": 50000, "price_butun": 125000, "color": "#0066FF",
        "features": ["/feed", "/heal", "/ec", "/kit claim", "40 ta mahsulotni auksionga sotish", "Region blok limiti: 12 ta", "Maksimal uylar soni: 15 ta"],
        "cmd": ["lp user {player} parent set magician"]
    },
    "LORD": {
        "price_1oy": 60000, "price_butun": 150000, "color": "#9900FF",
        "features": ["/bc", "/feed", "/repair", "/back", "/kit claim lord", "40 ta mahsulotni auksionga sotish", "Region blok limiti: 12 ta", "Maksimal uylar soni: 20 ta"],
        "cmd": ["lp user {player} parent set lord"]
    },
    "ASTRA++": {
        "price_1oy": 70000, "price_butun": 200000, "color": "#FF9900",
        "features": ["/unmute", "/repair all", "/kit claim lord", "70 ta mahsulotni auksionga sotish", "Region blok limiti: 160 ta", "Maksimal uylar soni: 25 ta"],
        "cmd": ["lp user {player} parent set astra"]
    },
    "DARK": {
        "price_1oy": 80000, "price_butun": 250000, "color": "#000000",
        "features": ["/fly", "/tempban", "/unban", "/ec {nik}", "/kit claim dark", "Teleport 0 soniya", "80 ta mahsulotni auksionga sotish", "Region blok limiti: 25 ta", "Maksimal uylar soni: 30 ta"],
        "cmd": ["lp user {player} parent set d"]
    }
}

def load_payments(): return json.load(open('payments.json','r',encoding='utf-8')) if os.path.exists('payments.json') else []
def save_payments(d): json.dump(d, open('payments.json','w',encoding='utf-8'), ensure_ascii=False, indent=2)

def get_server_status():
    try:
        server = JavaServer.lookup("65.108.106.30:20694")  # To'g'ridan-to'g'ri server
        status = server.status()
        return status.players.online, status.players.max
    except Exception as e:
        print("STATUS ERROR:", e)
        return 0, 0


def give_rank_minecraft(nick, rank):
    try:
        from mcrcon import MCRcon

        with MCRcon(
            host="65.108.106.30",
            password="18273645",
            port=25565
        ) as mcr:
            for cmd in RANKS[rank]['cmd']:
                resp = mcr.command(cmd.format(player=nick))
                print("RCON:", resp)

        return True

    except Exception as e:
        print("RCON ERROR:", e)

        with open('rank_commands.txt','a',encoding='utf-8') as f:
            f.write(f"\n{'='*70}\n{datetime.now()}\nERROR: {e}\n")
            f.write(f"Player: {nick}\nRank: {rank}\n")
            for cmd in RANKS[rank]['cmd']:
                f.write(f"{cmd.format(player=nick)}\n")

        return False


MAIN_HTML = '''<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DarkMine - Premium Server</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#000;color:#fff;overflow-x:hidden}
.bg{position:fixed;width:100%;height:100%;top:0;left:0;z-index:-2;background:radial-gradient(ellipse at bottom,#1b2735 0%,#090a0f 100%)}
.particles{position:fixed;width:100%;height:100%;top:0;left:0;z-index:-1}.particle{position:absolute;width:3px;height:3px;background:#fff;border-radius:50%;animation:float 15s infinite linear}
@keyframes float{0%,100%{opacity:0;transform:translateY(0)}10%{opacity:1}90%{opacity:1}100%{transform:translateY(-100vh) translateX(50px)}}
header{text-align:center;padding:100px 20px 80px;background:linear-gradient(180deg,rgba(0,0,0,0.9) 0%,transparent 100%)}
.logo{font-family:Orbitron,sans-serif;font-size:6em;font-weight:900;background:linear-gradient(45deg,#ff00ff,#00ffff,#ff00ff);background-size:300% 300%;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:logoAnim 4s ease infinite,glow 3s ease infinite;letter-spacing:15px;text-shadow:0 0 100px rgba(255,0,255,0.8)}
@keyframes logoAnim{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
@keyframes glow{0%,100%{filter:brightness(1) drop-shadow(0 0 30px #f0f)}50%{filter:brightness(1.8) drop-shadow(0 0 60px #0ff)}}
.server-info{margin-top:50px;background:rgba(255,255,255,0.05);backdrop-filter:blur(40px);padding:40px;border-radius:30px;display:inline-block;border:3px solid rgba(255,255,255,0.15);box-shadow:0 30px 80px rgba(0,255,255,0.3);animation:infoPulse 5s infinite}
@keyframes infoPulse{0%,100%{box-shadow:0 30px 80px rgba(0,255,255,0.3);transform:scale(1)}50%{box-shadow:0 40px 100px rgba(255,0,255,0.5);transform:scale(1.05)}}
.server-ip{font-family:Orbitron,sans-serif;font-size:2.2em;font-weight:700;color:#0ff;margin:20px 0;text-shadow:0 0 30px #0ff;animation:ipPulse 3s ease infinite}
@keyframes ipPulse{0%,100%{text-shadow:0 0 30px #0ff}50%{text-shadow:0 0 60px #0ff,0 0 90px #f0f}}
.online{font-size:1.6em;color:#0f0;margin-top:20px;display:flex;align-items:center;justify-content:center;gap:15px;font-weight:700}
.pulse-dot{width:18px;height:18px;background:#0f0;border-radius:50%;animation:dotPulse 2s infinite;box-shadow:0 0 30px #0f0}
@keyframes dotPulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.5);opacity:0.6}}
.container{max-width:1600px;margin:0 auto;padding:80px 30px}
.section-title{font-family:Orbitron,sans-serif;font-size:4.5em;text-align:center;margin-bottom:100px;background:linear-gradient(90deg,#fff,#0ff,#f0f,#fff);background-size:300% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:titleFlow 4s linear infinite}
@keyframes titleFlow{to{background-position:300% center}}
.ranks-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(350px,1fr));gap:50px;perspective:2000px}
.rank-card{background:rgba(15,15,25,0.7);backdrop-filter:blur(50px);border-radius:35px;padding:45px;border:3px solid rgba(255,255,255,0.1);transition:all 0.8s cubic-bezier(0.165,0.84,0.44,1);position:relative;overflow:hidden;cursor:pointer}
.rank-card::before{content:'';position:absolute;top:-100%;left:-100%;width:300%;height:300%;background:conic-gradient(from 0deg,transparent,var(--c),transparent 20%);animation:cardRotate 6s linear infinite;opacity:0;transition:opacity 0.8s}
@keyframes cardRotate{to{transform:rotate(360deg)}}
.rank-card::after{content:'';position:absolute;inset:3px;background:rgba(5,5,10,0.98);border-radius:32px;z-index:0}
.rank-card:hover::before{opacity:0.7}
.rank-card:hover{transform:translateY(-25px) scale(1.05);border-color:var(--c);box-shadow:0 40px 120px var(--s),0 0 80px var(--c)}
.rank-content{position:relative;z-index:1}
.rank-badge{position:absolute;top:25px;right:25px;background:linear-gradient(135deg,var(--c),#764ba2);padding:12px 25px;border-radius:30px;font-size:1em;font-weight:800;z-index:2;animation:badgeFloat 4s ease-in-out infinite;box-shadow:0 8px 30px var(--s)}
@keyframes badgeFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
.rank-name{font-family:Orbitron,sans-serif;font-size:3.2em;font-weight:900;color:var(--c);margin-bottom:30px;text-shadow:0 0 40px var(--c);animation:nameGlow 3s ease infinite}
@keyframes nameGlow{0%,100%{filter:brightness(1)}50%{filter:brightness(1.5)}}
.rank-prices{margin:25px 0}
.rank-price{font-size:1.4em;font-weight:700;color:var(--c);margin:12px 0;font-family:Orbitron,sans-serif;text-shadow:0 0 20px var(--c)}
.features{list-style:none;margin:35px 0}
.features li{padding:15px;margin:12px 0;background:rgba(255,255,255,0.04);border-radius:15px;border-left:5px solid var(--c);font-size:1.05em;transition:all 0.4s}
.features li:hover{background:rgba(255,255,255,0.1);transform:translateX(15px);border-left-width:8px}
.buy-btn{width:100%;padding:22px;background:linear-gradient(135deg,var(--c),#764ba2);color:#fff;border:none;border-radius:20px;font-size:1.4em;font-weight:800;cursor:pointer;font-family:Orbitron,sans-serif;text-transform:uppercase;position:relative;overflow:hidden;transition:all 0.5s;letter-spacing:3px;box-shadow:0 10px 40px var(--s)}
.buy-btn::before{content:'';position:absolute;top:50%;left:50%;width:0;height:0;background:rgba(255,255,255,0.5);border-radius:50%;transform:translate(-50%,-50%);transition:width 1s,height 1s}
.buy-btn:hover::before{width:500px;height:500px}
.buy-btn:hover{transform:scale(1.08);box-shadow:0 20px 70px var(--s)}
.buy-btn span{position:relative;z-index:1}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.97);backdrop-filter:blur(20px);z-index:99999;overflow-y:auto}
.modal-content{background:linear-gradient(135deg,rgba(20,20,50,0.99),rgba(50,20,70,0.99));backdrop-filter:blur(60px);max-width:700px;margin:80px auto;padding:60px;border-radius:40px;border:3px solid rgba(255,255,255,0.2);box-shadow:0 40px 150px rgba(255,0,255,0.5);position:relative}
.close{position:absolute;right:35px;top:30px;font-size:50px;cursor:pointer;color:#f0f;transition:all 0.5s;z-index:1}
.close:hover{color:#0ff;transform:rotate(180deg) scale(1.4)}
.modal h2{font-family:Orbitron,sans-serif;font-size:3em;margin-bottom:40px;background:linear-gradient(45deg,#f0f,#0ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.form-group{margin:30px 0}
label{display:block;margin-bottom:12px;font-weight:700;color:#0ff;font-size:1.2em;text-shadow:0 0 10px #0ff}
input,select{width:100%;padding:18px;border:3px solid rgba(255,255,255,0.2);border-radius:18px;font-size:1.15em;background:rgba(255,255,255,0.05);color:#fff;transition:all 0.4s}
input:focus,select:focus{outline:none;border-color:#0ff;background:rgba(255,255,255,0.12);box-shadow:0 0 40px rgba(0,255,255,0.5)}
input[readonly]{background:rgba(255,255,255,0.02);cursor:not-allowed}
select{cursor:pointer}
select option{background:#1a1a2e;color:#fff}
.card-info{background:linear-gradient(135deg,rgba(255,0,255,0.2),rgba(0,255,255,0.2));padding:35px;border-radius:25px;margin:35px 0;border:3px solid rgba(255,255,255,0.25);animation:cardPulse 5s infinite}
@keyframes cardPulse{0%,100%{box-shadow:0 10px 50px rgba(255,0,255,0.3)}50%{box-shadow:0 15px 70px rgba(0,255,255,0.5)}}
.card-number{font-family:Orbitron,sans-serif;font-size:2.2em;color:#0ff;margin:18px 0;letter-spacing:5px;text-shadow:0 0 25px #0ff}
.warning{background:rgba(255,165,0,0.2);border:3px solid #ffa500;padding:20px;border-radius:15px;color:#ffa500;margin:30px 0;font-weight:700}
.submit-btn{width:100%;padding:22px;background:linear-gradient(135deg,#f0f,#0ff);color:#fff;border:none;border-radius:20px;font-size:1.5em;font-weight:800;cursor:pointer;margin-top:35px;font-family:Orbitron,sans-serif;text-transform:uppercase;transition:all 0.5s;letter-spacing:3px;box-shadow:0 15px 60px rgba(255,0,255,0.5)}
.submit-btn:hover{transform:scale(1.08);box-shadow:0 25px 90px rgba(255,0,255,0.7)}
.submit-btn span{position:relative;z-index:1}
.message{padding:22px;border-radius:18px;margin-top:30px;display:none;text-align:center;font-weight:800;font-size:1.15em}
.success{background:linear-gradient(135deg,#0f0,#0c0);box-shadow:0 15px 50px rgba(0,255,0,0.5)}
.error{background:linear-gradient(135deg,#f00,#c00);box-shadow:0 15px 50px rgba(255,0,0,0.5)}
@media(max-width:768px){.logo{font-size:3.5em}.section-title{font-size:3em}.ranks-grid{grid-template-columns:1fr}}
</style></head><body>
<div class="bg"></div>
<div class="particles" id="particles"></div>
<header>
<div class="logo">⚔️ DARKMINE ⚔️</div>
<div class="server-info">
<div class="server-ip">🌐 darkmine.mchost.uz</div>
<div class="server-ip">🌐 darkmine.uz</div>
<div class="online"><span class="pulse-dot"></span><span>👥 Online: <strong>{{online}}</strong>/{{max_players}}</span>
</div>
</div>
</header>
<div class="container">
<h2 class="section-title">🏆 PREMIUM RANKS 🏆</h2>
<div class="ranks-grid">
{% for n,d in ranks.items() %}
<div class="rank-card" style="--c:{{d.color}};--s:{{d.color}}80">
<div class="rank-badge">⭐ PREMIUM</div>
<div class="rank-content">
<div class="rank-name">{{n}}</div>
<div class="rank-prices">
<div class="rank-price">1 oy: {{"{:,}".format(d.price_1oy)}} so'm</div>
<div class="rank-price">Butun umr: {{"{:,}".format(d.price_butun)}} so'm</div>
</div>
<ul class="features">{% for f in d.features %}<li>{{f}}</li>{% endfor %}</ul>
<button class="buy-btn" onclick="openModal('{{n}}',{{d.price_1oy}},{{d.price_butun}})"><span>🛒 SOTIB OLISH</span></button>
</div></div>
{% endfor %}
</div></div>
<div id="modal" class="modal"><div class="modal-content">
<span class="close" onclick="closeModal()">&times;</span>
<h2>💳 To'lov</h2>
<form id="form">
<div class="form-group"><label>🎯 Rank:</label><input type="text" id="rank" readonly></div>
<div class="form-group"><label>⏰ Muddat:</label>
<select id="duration" required onchange="updatePrice()">
<option value="">Tanlang</option>
<option value="1oy">1 oy</option>
<option value="butun">Butun umr</option>
</select>
</div>
<div class="form-group"><label>💰 Summa:</label><input type="text" id="price" readonly></div>
<div class="form-group"><label>👤 Minecraft Nick:</label><input type="text" id="nick" placeholder="Steve" required></div>
<div class="form-group"><label>📱 Telefon:</label><input type="tel" id="phone" placeholder="+998 90 123 45 67" required></div>
<div class="card-info">
<h3 style="color:#0ff;margin-bottom:12px;font-size:1.4em">💳 Pul O'tkazish:</h3>
<div class="card-number">{{card}}</div>
<p style="color:#f0f;font-size:1.4em;margin-top:15px;font-weight:700">{{holder}}</p>
</div>
<div class="warning">⚠️ <strong>MUHIM:</strong> To'lov chekini yuklash MAJBURIY! Agar chek tanlamasangiz rank ololmaysiz!</div>
<div class="form-group"><label>📸 Chek:</label><input type="file" id="file" accept="image/*" required></div>
<button type="submit" class="submit-btn"><span>🚀 YUBORISH</span></button>
<div id="msg" class="message"></div>
</form></div></div>
<script>
function createParticles(){const c=document.getElementById('particles');for(let i=0;i<150;i++){const p=document.createElement('div');p.className='particle';p.style.left=Math.random()*100+'%';p.style.top=Math.random()*100+'%';p.style.animationDelay=Math.random()*15+'s';c.appendChild(p)}}
createParticles();
let selRank='',price1oy=0,priceButun=0;
function openModal(r,p1,p2){selRank=r;price1oy=p1;priceButun=p2;document.getElementById('rank').value=r;document.getElementById('duration').value='';document.getElementById('price').value='';document.getElementById('modal').style.display='block'}
function closeModal(){document.getElementById('modal').style.display='none';document.getElementById('form').reset();document.getElementById('msg').style.display='none'}
function updatePrice(){const dur=document.getElementById('duration').value;if(dur=='1oy')document.getElementById('price').value=price1oy.toLocaleString('uz-UZ')+' so\\'m';else if(dur=='butun')document.getElementById('price').value=priceButun.toLocaleString('uz-UZ')+' so\\'m'}
document.getElementById('form').onsubmit=async(e)=>{e.preventDefault();const dur=document.getElementById('duration').value;const finalPrice=dur=='1oy'?price1oy:priceButun;const fd=new FormData();fd.append('rank',selRank);fd.append('duration',dur);fd.append('price',finalPrice);fd.append('nickname',document.getElementById('nick').value);fd.append('phone',document.getElementById('phone').value);fd.append('receipt',document.getElementById('file').files[0]);
try{const r=await fetch('/payment',{method:'POST',body:fd});const d=await r.json();const m=document.getElementById('msg');if(d.success){m.className='message success';m.textContent='✅ Yuborildi! Admin tasdiqlaydi.';m.style.display='block';setTimeout(closeModal,3000)}else{m.className='message error';m.textContent='❌ '+d.error;m.style.display='block'}}catch(err){const m=document.getElementById('msg');m.className='message error';m.textContent='❌ Xatolik!';m.style.display='block'}};
window.onclick=(e)=>{if(e.target==document.getElementById('modal'))closeModal()};
</script></body></html>'''

ADMIN_HTML = '''<html><head><meta charset="UTF-8"><title>Admin - DarkMine</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial;background:linear-gradient(135deg,#667eea,#764ba2);padding:20px;min-height:100vh}
.container{max-width:1600px;margin:0 auto;background:rgba(255,255,255,0.98);border-radius:25px;padding:40px;box-shadow:0 20px 80px rgba(0,0,0,0.3)}
h1{font-family:Orbitron,sans-serif;color:#667eea;margin-bottom:40px;text-align:center;font-size:3em;text-shadow:0 2px 10px rgba(102,126,234,0.3)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:25px;margin-bottom:50px}
.stat-card{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:30px;border-radius:20px;text-align:center;box-shadow:0 10px 30px rgba(0,0,0,0.2);transition:transform 0.3s}
.stat-card:hover{transform:translateY(-8px)}
.stat-card p{font-size:1.1em;margin-bottom:15px;opacity:0.9}
.stat-card h3{font-size:2.8em;margin:15px 0;font-family:Orbitron,sans-serif}
table{width:100%;border-collapse:collapse;box-shadow:0 8px 30px rgba(0,0,0,0.15);background:#fff;border-radius:15px;overflow:hidden}
th,td{padding:18px;text-align:left;border-bottom:1px solid #e0e0e0}
th{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-weight:800;font-size:1.05em}
tr:hover{background:#f8f8ff}
.btn{padding:10px 18px;border:none;border-radius:8px;cursor:pointer;font-weight:700;margin:0 6px;transition:all 0.3s;font-size:0.95em}
.approve{background:#4CAF50;color:#fff}.approve:hover{background:#45a049;transform:scale(1.08)}
.reject{background:#f44336;color:#fff}.reject:hover{background:#da190b;transform:scale(1.08)}
.view-receipt{background:#2196F3;color:#fff;text-decoration:none;padding:8px 15px;border-radius:6px;display:inline-block}.view-receipt:hover{background:#0b7dda}
.pending{color:#ff9800;font-weight:800}.approved{color:#4CAF50;font-weight:800}.rejected{color:#f44336;font-weight:800}
.logout{position:absolute;top:25px;right:25px;background:#f44336;color:#fff;padding:12px 25px;border-radius:10px;text-decoration:none;font-weight:700;font-size:1.05em;box-shadow:0 5px 20px rgba(244,67,54,0.4)}
.logout:hover{background:#da190b;transform:scale(1.05)}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.9);z-index:9999;justify-content:center;align-items:center}
.modal img{max-width:90%;max-height:90%;border-radius:15px;box-shadow:0 20px 80px rgba(255,255,255,0.3)}
.modal-close{position:absolute;top:30px;right:40px;font-size:50px;color:#fff;cursor:pointer;transition:all 0.3s}
.modal-close:hover{transform:scale(1.2);color:#f44336}
</style></head><body>
<a href="/admin/logout" class="logout">🚪 Chiqish</a>
<div class="container">
<h1>⚙️ ADMIN PANEL</h1>
<div class="stats">
<div class="stat-card"><p>📊 Jami To'lovlar</p><h3>{{p|length}}</h3></div>
<div class="stat-card"><p>⏳ Kutilmoqda</p><h3>{{p|selectattr('status','equalto','pending')|list|length}}</h3></div>
<div class="stat-card"><p>✅ Tasdiqlangan</p><h3>{{p|selectattr('status','equalto','approved')|list|length}}</h3></div>
<div class="stat-card"><p>❌ Rad Etilgan</p><h3>{{p|selectattr('status','equalto','rejected')|list|length}}</h3></div>
</div>
<table>
<thead><tr><th>ID</th><th>Sana</th><th>Nick</th><th>Rank</th><th>Muddat</th><th>Summa</th><th>Telefon</th><th>Status</th><th>Chek</th><th>Amallar</th></tr></thead>
<tbody>
{% for pay in p|reverse %}
<tr>
<td>{{pay.id}}</td>
<td>{{pay.timestamp}}</td>
<td><strong>{{pay.nickname}}</strong></td>
<td style="color:{{ranks[pay.rank].color}};font-weight:800">{{pay.rank}}</td>
<td>{{pay.duration}}</td>
<td><strong>{{"{:,}".format(pay.price)}}</strong> so'm</td>
<td>{{pay.phone}}</td>
<td class="{{pay.status}}">{{pay.status.upper()}}</td>
<td><a href="/receipts/{{pay.receipt}}" class="view-receipt" target="_blank">📸 Ko'rish</a></td>
<td>
{% if pay.status == 'pending' %}
<button class="btn approve" onclick="updateStatus('{{pay.id}}','approved')">✅ Tasdiqlash</button>
<button class="btn reject" onclick="updateStatus('{{pay.id}}','rejected')">❌ Rad</button>
{% else %}
<span style="color:#888">-</span>
{% endif %}
</td>
</tr>
{% endfor %}
</tbody>
</table>
</div>
<div id="imageModal" class="modal" onclick="closeImageModal()">
<span class="modal-close">&times;</span>
<img id="modalImage" src="">
</div>
<script>
async function updateStatus(id,status){
if(!confirm(`To'lovni ${status=='approved'?'tasdiqlash':'rad etish'}ni xohlaysizmi?`))return;
try{
const r=await fetch('/admin/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,status})});
const d=await r.json();
if(d.success){alert(d.message);location.reload()}else{alert('Xatolik: '+d.error)}
}catch(err){alert('Xatolik yuz berdi!')}
}
function closeImageModal(){document.getElementById('imageModal').style.display='none'}
</script>
</body></html>'''


@app.route('/')
def index():
    online, max_players = get_server_status()
    return render_template_string(
        MAIN_HTML,
        ranks=RANKS,
        card=CARD_NUMBER,
        holder=CARD_HOLDER,
        online=online,
        max_players=max_players
    )


@app.route('/payment', methods=['POST'])
def payment():
    try:
        rank = request.form.get('rank')
        duration = request.form.get('duration')
        price = int(request.form.get('price'))
        nickname = request.form.get('nickname')
        phone = request.form.get('phone')
        file = request.files.get('receipt')

        if not all([rank, duration, price, nickname, phone, file]):
            return jsonify({'success': False, 'error': 'Barcha maydonlarni to\'ldiring!'})

        if rank not in RANKS:
            return jsonify({'success': False, 'error': 'Noto\'g\'ri rank!'})

        filename = secure_filename(f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{nickname}_{file.filename}")
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        payments = load_payments()
        payment_id = str(len(payments) + 1)

        new_payment = {
            'id': payment_id,
            'rank': rank,
            'duration': duration,
            'price': price,
            'nickname': nickname,
            'phone': phone,
            'receipt': filename,
            'status': 'pending',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        payments.append(new_payment)
        save_payments(payments)

        return jsonify({'success': True, 'message': 'To\'lov yuborildi!'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/admin')
def admin_login():
    if 'admin' in session:
        return redirect('/admin/dashboard')
    return '''
    <html><head><meta charset="UTF-8"><title>Admin Login</title>
    <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:Arial;background:linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;display:flex;justify-content:center;align-items:center}
    .login-box{background:#fff;padding:50px;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3);width:400px}
    h2{text-align:center;color:#667eea;margin-bottom:30px;font-size:2em}
    input{width:100%;padding:15px;margin:15px 0;border:2px solid #ddd;border-radius:10px;font-size:1em}
    input:focus{outline:none;border-color:#667eea}
    button{width:100%;padding:15px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:10px;font-size:1.1em;font-weight:700;cursor:pointer;margin-top:10px}
    button:hover{transform:scale(1.05)}
    .error{color:#f44336;text-align:center;margin-top:15px;display:none}
    </style></head><body>
    <div class="login-box">
    <h2>🔐 Admin Login</h2>
    <form id="loginForm">
    <input type="text" id="username" placeholder="Username" required>
    <input type="password" id="password" placeholder="Password" required>
    <button type="submit">Kirish</button>
    <div class="error" id="error">Username yoki parol xato!</div>
    </form>
    </div>
    <script>
    document.getElementById('loginForm').onsubmit=async(e)=>{
    e.preventDefault();
    const fd=new FormData();
    fd.append('username',document.getElementById('username').value);
    fd.append('password',document.getElementById('password').value);
    const r=await fetch('/admin/login',{method:'POST',body:fd});
    const d=await r.json();
    if(d.success){window.location.href='/admin/dashboard'}else{document.getElementById('error').style.display='block'}
    };
    </script></body></html>
    '''


@app.route('/admin/login', methods=['POST'])
def admin_login_post():
    username = request.form.get('username')
    password = request.form.get('password')
    if username == ADMIN_USER and password == ADMIN_PASS:
        session['admin'] = True
        return jsonify({'success': True})
    return jsonify({'success': False})


@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin' not in session:
        return redirect('/admin')
    payments = load_payments()
    return render_template_string(ADMIN_HTML, p=payments, ranks=RANKS)


@app.route('/admin/update', methods=['POST'])
def admin_update():
    if 'admin' not in session:
        return jsonify({'success': False, 'error': 'Unauthorized'})

    data = request.json
    payment_id = data.get('id')
    new_status = data.get('status')

    payments = load_payments()

    for payment in payments:
        if payment['id'] == payment_id:
            payment['status'] = new_status


            if new_status == 'approved':
                success = give_rank_minecraft(payment['nickname'], payment['rank'])
                if success:
                    save_payments(payments)
                    return jsonify({'success': True, 'message': 'Tasdiqlandi va rank berildi!'})
                else:
                    return jsonify({'success': False, 'error': 'Rank berishda xatolik!'})

            save_payments(payments)
            return jsonify({'success': True, 'message': 'Status o\'zgartirildi!'})

    return jsonify({'success': False, 'error': 'To\'lov topilmadi!'})


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect('/admin')


@app.route('/receipts/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)